# ikurd-backend (minimal)
.env: copy from .env.example and set MONGO_URI and JWT_SECRET
Install:
  cd backend
  npm install
Run (dev):
  npm run dev
