# frontend (Vite + React)
Install:
  cd frontend
  npm install
Run:
  npm run dev
Note: API base is http://localhost:5000/api by default (change VITE_API_URL env var).
